-- PHONETICS STARTER DATABASE SCHEMA
-- Run only in a NEW Supabase project. Read README before applying.
-- Private tables are never readable by anonymous visitors. RLS is enabled.
create extension if not exists pgcrypto;

create table if not exists public.admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.admin_users enable row level security;
-- Only the same authenticated user can check whether they are registered as admin.
create policy "admin can read own authorization row" on public.admin_users
  for select to authenticated using (user_id = auth.uid());

create table if not exists public.seller_submissions (
  id uuid primary key default gen_random_uuid(),
  seller_name text not null,
  seller_mobile text not null,
  seller_city text not null,
  phone_model text not null,
  phone_condition text not null,
  phone_storage text not null,
  asking_price numeric(12,2) not null check (asking_price > 0),
  proof_available boolean not null default false,
  proof_path text,
  photo_urls jsonb not null default '[]'::jsonb,
  phone_notes text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  selling_price numeric(12,2) check (selling_price is null or selling_price > 0),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.seller_submissions enable row level security;
create policy "admins manage seller submissions" on public.seller_submissions
  for all to authenticated using (exists(select 1 from public.admin_users a where a.user_id=auth.uid()))
  with check (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));

create table if not exists public.phone_listings (
  id uuid primary key default gen_random_uuid(),
  seller_submission_id uuid unique references public.seller_submissions(id),
  brand text not null,
  model text not null,
  condition text not null,
  ram text,
  storage text,
  selling_price numeric(12,2) not null check (selling_price > 0),
  public_status text not null default 'hidden' check (public_status in ('available','reserved','sold','hidden')),
  photo_urls jsonb not null default '[]'::jsonb,
  created_at timestamptz not null default now()
);
alter table public.phone_listings enable row level security;
create policy "public can read available listings" on public.phone_listings
  for select to anon, authenticated using (public_status = 'available');
create policy "admins manage listings" on public.phone_listings
  for all to authenticated using (exists(select 1 from public.admin_users a where a.user_id=auth.uid()))
  with check (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));

create or replace view public.public_listings with (security_invoker = true) as
select id, brand, model, condition, ram, storage, selling_price, public_status, photo_urls, created_at
from public.phone_listings where public_status='available';
grant select on public.public_listings to anon, authenticated;

create table if not exists public.buyer_requests (
  id uuid primary key default gen_random_uuid(),
  buyer_name text not null,
  buyer_mobile text not null,
  buyer_email text,
  buyer_city text not null,
  listing_id uuid references public.phone_listings(id),
  phone_model text not null,
  selling_price numeric(12,2) not null check (selling_price > 0),
  status text not null default 'pending' check (status in ('pending','contacted','accepted','rejected','fulfilled','cancelled')),
  created_at timestamptz not null default now()
);
alter table public.buyer_requests enable row level security;
create policy "admins manage buyer requests" on public.buyer_requests
  for all to authenticated using (exists(select 1 from public.admin_users a where a.user_id=auth.uid()))
  with check (exists(select 1 from public.admin_users a where a.user_id=auth.uid()));

-- Storage buckets: create via Dashboard as described in README.
-- `public-phone-photos` can serve only reviewed public photos.
-- `private-proofs` must be PRIVATE. Add authenticated-admin policies only.
-- IMPORTANT: Public browser must NOT insert directly into private tables.
-- The Edge Functions submit-seller and submit-buyer must validate input and use
-- server-side credentials stored as Supabase secrets, then write records safely.
-- Edge Functions are intentionally separate deployable units; see README.
