/* Copy this file to config.js and fill in the Supabase Project URL and anon/publishable key.
   The anon key is intended for browser use only when database RLS policies are correct.
   NEVER put service_role keys, database passwords, or EmailJS private keys here. */
window.PHONETICS_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabaseAnonKey: "YOUR_SUPABASE_ANON_OR_PUBLISHABLE_KEY"
};