// Phonetics public configuration. Publishable key is intended for browser use.
// Never add a Supabase secret/service_role key here.
window.PHONETICS_CONFIG = {
  supabaseUrl: "https://vxzdqymcmwlicsopnwd.supabase.co",
  supabaseAnonKey: "sb_publishable_m4pCpDCOEcPqJPdDT_4v2w_Re55TRhp"
};
