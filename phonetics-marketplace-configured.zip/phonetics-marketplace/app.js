/* Phonetics public frontend. Configure Supabase + EmailJS in config.js after following README.
   Do not place Supabase service_role keys or any private secret in browser files. */
const PHONETICS_CONFIG = window.PHONETICS_CONFIG || {};
const EMAILJS_CONFIG = {
  serviceId: "service_rf7s8dh",
  sellerTemplateId: "template_m4r9o4s",
  buyerTemplateId: "template_68v8194",
  publicKey: "js4Cs0f0vvNe9dLON"
};
const supabaseReady = !!(PHONETICS_CONFIG.supabaseUrl && PHONETICS_CONFIG.supabaseAnonKey && window.supabase);
const db = supabaseReady ? window.supabase.createClient(PHONETICS_CONFIG.supabaseUrl, PHONETICS_CONFIG.supabaseAnonKey) : null;
const $ = (s, root=document) => root.querySelector(s);
let listings = [];

document.addEventListener("DOMContentLoaded", () => {
  $("#year").textContent = new Date().getFullYear();
  const toggle = $("#menu-toggle"), nav = $("#main-nav");
  toggle.addEventListener("click", () => { const open = nav.classList.toggle("open"); toggle.setAttribute("aria-expanded", String(open)); });
  nav.querySelectorAll("a").forEach(a => a.addEventListener("click", () => nav.classList.remove("open")));
  $("#phone-search").addEventListener("input", renderListings);
  $("#condition-filter").addEventListener("change", renderListings);
  $("#seller-form").addEventListener("submit", submitSeller);
  $("#buyer-form").addEventListener("submit", submitBuyer);
  $("#close-dialog").addEventListener("click", () => $("#purchase-dialog").close());
  if (window.emailjs && EMAILJS_CONFIG.publicKey) {
    try { window.emailjs.init({ publicKey: EMAILJS_CONFIG.publicKey }); } catch (e) { console.warn("EmailJS init issue", e); }
  }
  loadListings();
});

async function loadListings() {
  const status = $("#listing-status");
  if (!db) {
    status.textContent = "Setup pending: approved phones will appear here after the secure database is configured. No demo or fake listings are shown.";
    return;
  }
  try {
    const { data, error } = await db.from("public_listings").select("id,brand,model,condition,ram,storage,selling_price,public_status,photo_urls,created_at").eq("public_status", "available").order("created_at", { ascending: false });
    if (error) throw error;
    listings = data || [];
    renderListings();
  } catch (e) {
    console.error(e);
    status.textContent = "Phones could not be loaded. Please try again later.";
  }
}
function renderListings() {
  const grid = $("#phone-grid"), status = $("#listing-status");
  if (!db) return;
  const q = ($("#phone-search").value || "").trim().toLowerCase(), cond = $("#condition-filter").value;
  const shown = listings.filter(x => (`${x.brand||""} ${x.model||""}`).toLowerCase().includes(q) && (!cond || x.condition === cond));
  grid.replaceChildren();
  if (!shown.length) { status.hidden = false; status.textContent = listings.length ? "No phones match your search. Try another search." : "Abhi koi approved phone available nahi hai. Baad mein dobara check karein."; return; }
  status.hidden = true;
  shown.forEach(item => {
    const card = document.createElement("article"); card.className = "phone-card";
    if (Array.isArray(item.photo_urls) && item.photo_urls[0]) {
      const img = document.createElement("img"); img.src = item.photo_urls[0]; img.alt = `${item.brand||""} ${item.model||"phone"}`; img.loading = "lazy"; card.append(img);
    } else { const ph = document.createElement("div"); ph.className = "phone-placeholder"; ph.textContent = "P"; card.append(ph); }
    const body = document.createElement("div"); body.className = "phone-card-body";
    const title = document.createElement("h3"); title.textContent = `${item.brand || ""} ${item.model || ""}`.trim() || "Phone";
    const badge = document.createElement("span"); badge.className = "badge"; badge.textContent = item.condition || "Reviewed";
    const specs = document.createElement("p"); specs.className = "specs"; specs.textContent = `${item.ram ? item.ram+" RAM · " : ""}${item.storage || "Storage not specified"}`;
    const price = document.createElement("p"); price.className = "price"; price.textContent = rupees(item.selling_price);
    const btn = document.createElement("button"); btn.className = "button button-gold"; btn.textContent = "Request to Buy"; btn.type = "button"; btn.addEventListener("click", () => openPurchase(item));
    body.append(title,badge,specs,price,btn); card.append(body); grid.append(card);
  });
}
function rupees(n) { const num = Number(n); return Number.isFinite(num) ? new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR",maximumFractionDigits:0}).format(num) : "Price on request"; }
function openPurchase(item) {
  const form = $("#buyer-form");
  form.elements.listing_id.value = item.id;
  form.elements.phone_model.value = `${item.brand||""} ${item.model||""}`.trim();
  form.elements.selling_price.value = item.selling_price;
  $("#selected-phone").textContent = `${form.elements.phone_model.value} — ${rupees(item.selling_price)}`;
  $("#buyer-message").textContent = "";
  $("#purchase-dialog").showModal();
}
function showMessage(el, msg, type="") { el.textContent = msg; el.className = `form-message ${type}`.trim(); }
async function sendEmail(templateId, params) {
  if (!window.emailjs || !EMAILJS_CONFIG.publicKey) throw new Error("EmailJS browser SDK/configuration is unavailable.");
  return window.emailjs.send(EMAILJS_CONFIG.serviceId, templateId, params);
}
async function submitSeller(event) {
  event.preventDefault();
  const form = event.currentTarget, msg = $("#seller-message"), fd = new FormData(form);
  if (fd.get("proof_available") !== "yes") { showMessage(msg, "Original bill ya Phonetics dwara accepted proof ke bina submission approve nahi ho sakta. Proof available hone par hi submit karein.", "error"); return; }
  if (!db) { showMessage(msg, "Submission save nahi hui: database abhi configure nahi hai. README ke setup steps complete karein.", "error"); return; }
  const photos = form.elements.phone_photos.files, proof = form.elements.proof_file.files[0];
  if (!photos.length || photos.length > 5 || [...photos].some(f => !["image/jpeg","image/png","image/webp"].includes(f.type) || f.size > 5*1024*1024)) { showMessage(msg,"1–5 photos chunein. Sirf JPG, PNG, WEBP; har photo 5 MB tak.", "error"); return; }
  if (!proof || !["image/jpeg","image/png","application/pdf"].includes(proof.type) || proof.size > 8*1024*1024) { showMessage(msg,"Bill/proof JPG, PNG ya PDF mein ho aur 8 MB tak ho.", "error"); return; }
  showMessage(msg,"Secure submission bhej rahe hain…");
  try {
    // The secure Edge Function validates user input and writes private records/files.
    const { data: { session } } = await db.auth.getSession();
    const uploads = new FormData();
    ["seller_name","seller_mobile","seller_city","phone_model","phone_condition","phone_storage","asking_price","proof_available","phone_notes"].forEach(k => uploads.append(k, String(fd.get(k)||"")));
    [...photos].forEach(f => uploads.append("phone_photos", f));
    uploads.append("proof_file", proof);
    const response = await fetch(`${PHONETICS_CONFIG.supabaseUrl}/functions/v1/submit-seller`, { method:"POST", headers: session?.access_token ? {Authorization:`Bearer ${session.access_token}`} : {}, body:uploads });
    const result = await response.json().catch(()=>({}));
    if (!response.ok || !result.success) throw new Error(result.error || "Secure backend submission failed.");
    // Email is notification only; database success remains distinct from email success.
    let emailOk = false;
    try { await sendEmail(EMAILJS_CONFIG.sellerTemplateId, result.emailParams || {}); emailOk = true; } catch(e) { console.error("Seller email notification failed",e); }
    form.reset();
    showMessage(msg, emailOk ? "Submission save ho gayi. Phonetics review karega; email notification bhi send hui." : "Submission save ho gayi, lekin email notification send nahi hui. Admin ko dashboard mein record check karna hoga.", "success");
  } catch (e) {
    console.error(e); showMessage(msg, `Submission save nahi hui: ${e.message || "unknown error"}`, "error");
  }
}
async function submitBuyer(event) {
  event.preventDefault();
  const form = event.currentTarget, msg = $("#buyer-message"), fd = new FormData(form);
  if (!db) { showMessage(msg,"Request save nahi hui: database abhi configure nahi hai.","error"); return; }
  showMessage(msg,"Purchase request bhej rahe hain…");
  try {
    const { data: { session } } = await db.auth.getSession();
    const response = await fetch(`${PHONETICS_CONFIG.supabaseUrl}/functions/v1/submit-buyer`, {method:"POST",headers:{"Content-Type":"application/json",...(session?.access_token?{Authorization:`Bearer ${session.access_token}`}:{})},body:JSON.stringify({buyer_name:fd.get("buyer_name"),buyer_mobile:fd.get("buyer_mobile"),buyer_email:fd.get("buyer_email"),buyer_city:fd.get("buyer_city"),listing_id:fd.get("listing_id")})});
    const result = await response.json().catch(()=>({}));
    if (!response.ok || !result.success) throw new Error(result.error || "Secure backend request failed.");
    let emailOk = false;
    try { await sendEmail(EMAILJS_CONFIG.buyerTemplateId, result.emailParams || {}); emailOk = true; } catch(e) { console.error("Buyer email notification failed",e); }
    form.reset(); $("#purchase-dialog").close();
    alert(emailOk ? "Purchase request save ho gayi aur notification send hui. Yeh abhi completed purchase nahi hai." : "Purchase request save ho gayi, lekin email notification send nahi hui. Yeh completed purchase nahi hai.");
  } catch(e) { console.error(e); showMessage(msg,`Request save nahi hui: ${e.message || "unknown error"}`,"error"); }
}
